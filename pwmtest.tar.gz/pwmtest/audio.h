#ifndef AUDIO_H
#define AUDIO_H

void play(uint32_t* abuffer, uint32_t abuffer_size, uint32_t samplerate);
void stop();

#endif