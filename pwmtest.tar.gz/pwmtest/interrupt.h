#ifndef INTERRUPT_H
#define INTERRUPT_H

void enable_irq(uint8_t irq);
void disable_irq(uint8_t irq);
void set_as_fiq(uint8_t irq);
void activate_ints();
void deactivate_ints();
void init_interrupts(void (*fiq_handler)(void), void (*irq_handler)(void));
void unregister();

#endif