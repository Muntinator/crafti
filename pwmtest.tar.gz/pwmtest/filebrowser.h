#ifndef _FILEBROWSER_H_
#define _FILEBROWSER_H_

int filebrowser(uint8_t* scrbuf, char* file);//returns 0 on success, 1 if no file has been chosen; sets file to the path of the selected file

#endif
