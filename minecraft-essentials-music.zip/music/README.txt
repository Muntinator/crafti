Minecraft Alpha essential music subset

Included tracks:
- Minecraft
- Sweden
- Haggstrom
- Subwoofer Lullaby
- Living Mice
- Mice on Venus
- Wet Hands
- Dry Hands

Audio is downsampled to mono 22.05 kHz / 48 kbps to keep the pack small and practical for calculator/game-port use.
